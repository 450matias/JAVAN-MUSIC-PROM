import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Shuffle, Repeat, Heart, Music } from 'lucide-react';
import { Track } from '../types/music';

interface MusicPlayerProps {
  track: Track;
  isPlaying: boolean;
  onPlayPause: () => void;
  tracks: Track[];
  onTrackChange: (track: Track) => void;
}

export const MusicPlayer: React.FC<MusicPlayerProps> = ({
  track,
  isPlaying,
  onPlayPause,
  tracks,
  onTrackChange,
}) => {
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState<'none' | 'one' | 'all'>('none');
  
  const audioRef = useRef<HTMLAudioElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);

  // Initialize audio element
  useEffect(() => {
    if (audioRef.current && track) {
      audioRef.current.src = track.audioUrl;
      audioRef.current.load();
      setCurrentTime(0);
    }
  }, [track]);

  // Handle play/pause
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play();
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  // Update current time
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const handleEnded = () => {
      if (repeatMode === 'one') {
        audio.currentTime = 0;
        audio.play();
      } else {
        handleNext();
      }
    };

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [repeatMode]);

  // Handle volume
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (progressBarRef.current && audioRef.current && track.duration) {
      const rect = progressBarRef.current.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const progressWidth = rect.width;
      const clickProgress = clickX / progressWidth;
      const newTime = clickProgress * track.duration;
      
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const getCurrentTrackIndex = () => {
    return tracks.findIndex(t => t.id === track.id);
  };

  const handleNext = () => {
    const currentIndex = getCurrentTrackIndex();
    let nextIndex;

    if (isShuffled) {
      nextIndex = Math.floor(Math.random() * tracks.length);
    } else if (repeatMode === 'all') {
      nextIndex = (currentIndex + 1) % tracks.length;
    } else {
      nextIndex = currentIndex + 1;
      if (nextIndex >= tracks.length) return; // Don't loop if not in repeat all mode
    }

    onTrackChange(tracks[nextIndex]);
  };

  const handlePrevious = () => {
    const currentIndex = getCurrentTrackIndex();
    let prevIndex;

    if (currentTime > 3) {
      // If more than 3 seconds into the song, restart it
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        setCurrentTime(0);
      }
      return;
    }

    if (isShuffled) {
      prevIndex = Math.floor(Math.random() * tracks.length);
    } else if (repeatMode === 'all') {
      prevIndex = currentIndex - 1;
      if (prevIndex < 0) prevIndex = tracks.length - 1;
    } else {
      prevIndex = currentIndex - 1;
      if (prevIndex < 0) return; // Don't loop if not in repeat all mode
    }

    onTrackChange(tracks[prevIndex]);
  };

  const toggleRepeat = () => {
    const modes: Array<'none' | 'one' | 'all'> = ['none', 'one', 'all'];
    const currentIndex = modes.indexOf(repeatMode);
    setRepeatMode(modes[(currentIndex + 1) % modes.length]);
  };

  const progress = track.duration ? (currentTime / track.duration) * 100 : 0;

  return (
    <>
      <audio ref={audioRef} preload="metadata" />
      
      <div className="fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-xl border-t border-white/10 z-50">
        <div className="container mx-auto px-4 py-4">
          {/* Progress Bar */}
          <div className="mb-4">
            <div
              ref={progressBarRef}
              onClick={handleProgressClick}
              className="h-1 bg-gray-600 rounded-full cursor-pointer group hover:h-2 transition-all duration-200"
            >
              <div
                className="h-full bg-gradient-to-r from-purple-600 to-pink-600 rounded-full relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(track.duration)}</span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            {/* Track Info */}
            <div className="flex items-center space-x-4 flex-1 min-w-0">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                {track.artworkUrl ? (
                  <img
                    src={track.artworkUrl}
                    alt={track.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Music className="w-6 h-6 text-white" />
                )}
              </div>
              
              <div className="min-w-0">
                <h3 className="text-white font-semibold truncate">{track.title}</h3>
                <p className="text-gray-400 text-sm truncate">{track.artist}</p>
              </div>
              
              <button
                onClick={() => setIsLiked(!isLiked)}
                className={`p-2 rounded-full transition-colors ${
                  isLiked ? 'text-pink-500 hover:text-pink-400' : 'text-gray-400 hover:text-white'
                }`}
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Player Controls */}
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setIsShuffled(!isShuffled)}
                className={`p-2 rounded-full transition-colors ${
                  isShuffled ? 'text-purple-400' : 'text-gray-400 hover:text-white'
                }`}
              >
                <Shuffle className="w-4 h-4" />
              </button>
              
              <button
                onClick={handlePrevious}
                className="text-gray-400 hover:text-white transition-colors p-2"
                disabled={!isShuffled && repeatMode !== 'all' && getCurrentTrackIndex() === 0}
              >
                <SkipBack className="w-5 h-5" />
              </button>
              
              <button
                onClick={onPlayPause}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white p-3 rounded-full transition-all duration-300 transform hover:scale-105"
              >
                {isPlaying ? (
                  <Pause className="w-6 h-6" />
                ) : (
                  <Play className="w-6 h-6 ml-0.5" />
                )}
              </button>
              
              <button
                onClick={handleNext}
                className="text-gray-400 hover:text-white transition-colors p-2"
                disabled={!isShuffled && repeatMode !== 'all' && getCurrentTrackIndex() === tracks.length - 1}
              >
                <SkipForward className="w-5 h-5" />
              </button>
              
              <button
                onClick={toggleRepeat}
                className={`p-2 rounded-full transition-colors ${
                  repeatMode !== 'none' ? 'text-purple-400' : 'text-gray-400 hover:text-white'
                }`}
              >
                <Repeat className="w-4 h-4" />
                {repeatMode === 'one' && (
                  <span className="absolute -mt-1 -ml-1 text-xs">1</span>
                )}
              </button>
            </div>

            {/* Volume Control */}
            <div className="flex items-center space-x-3 flex-1 justify-end">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-5 h-5" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>
              
              <div className="w-24 h-1 bg-gray-600 rounded-full">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={isMuted ? 0 : volume}
                  onChange={(e) => {
                    const newVolume = parseFloat(e.target.value);
                    setVolume(newVolume);
                    if (newVolume > 0) setIsMuted(false);
                  }}
                  className="w-full h-1 bg-transparent appearance-none cursor-pointer volume-slider"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};