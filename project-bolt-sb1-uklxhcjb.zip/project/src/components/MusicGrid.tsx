import React from 'react';
import { Play, Pause, Music, Clock, Calendar, User } from 'lucide-react';
import { Track } from '../types/music';

interface MusicGridProps {
  tracks: Track[];
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
}

export const MusicGrid: React.FC<MusicGridProps> = ({
  tracks,
  currentTrack,
  isPlaying,
  onPlayTrack,
}) => {
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(new Date(date));
  };

  const isCurrentTrack = (track: Track) => {
    return currentTrack?.id === track.id;
  };

  if (tracks.length === 0) {
    return (
      <div className="text-center py-20">
        <Music className="w-20 h-20 text-purple-400 mx-auto mb-6" />
        <h3 className="text-xl font-semibold text-white mb-2">No tracks found</h3>
        <p className="text-gray-400">Try adjusting your search or upload some music.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Grid View for larger screens */}
      <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {tracks.map((track) => (
          <div
            key={track.id}
            className="group bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-4 hover:bg-white/15 transition-all duration-300 hover:scale-105 hover:shadow-xl"
          >
            {/* Artwork */}
            <div className="relative mb-4">
              <div className="aspect-square bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg overflow-hidden">
                {track.artworkUrl ? (
                  <img
                    src={track.artworkUrl}
                    alt={track.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Music className="w-12 h-12 text-white" />
                  </div>
                )}
              </div>
              
              {/* Play/Pause Button Overlay */}
              <button
                onClick={() => onPlayTrack(track)}
                className={`absolute inset-0 bg-black/50 backdrop-blur-sm rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 ${
                  isCurrentTrack(track) ? 'opacity-100' : ''
                }`}
              >
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-3 rounded-full transform transition-transform hover:scale-110">
                  {isCurrentTrack(track) && isPlaying ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-white ml-0.5" />
                  )}
                </div>
              </button>
            </div>
            
            {/* Track Info */}
            <div className="space-y-2">
              <h3 className="font-semibold text-white truncate group-hover:text-purple-300 transition-colors">
                {track.title}
              </h3>
              <p className="text-gray-400 text-sm truncate flex items-center">
                <User className="w-3 h-3 mr-1" />
                {track.artist}
              </p>
              
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span className="flex items-center">
                  <Clock className="w-3 h-3 mr-1" />
                  {formatDuration(track.duration)}
                </span>
                <span className="flex items-center">
                  <Calendar className="w-3 h-3 mr-1" />
                  {formatDate(track.uploadedAt)}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* List View for mobile */}
      <div className="md:hidden space-y-3">
        {tracks.map((track) => (
          <div
            key={track.id}
            className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-4 hover:bg-white/15 transition-all duration-300"
          >
            <div className="flex items-center space-x-4">
              {/* Artwork */}
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg overflow-hidden flex-shrink-0">
                {track.artworkUrl ? (
                  <img
                    src={track.artworkUrl}
                    alt={track.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Music className="w-6 h-6 text-white" />
                  </div>
                )}
              </div>
              
              {/* Track Info */}
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-white truncate">
                  {track.title}
                </h3>
                <p className="text-gray-400 text-sm truncate">
                  {track.artist}
                </p>
                <div className="flex items-center space-x-4 text-xs text-gray-500 mt-1">
                  <span>{formatDuration(track.duration)}</span>
                  <span>{formatDate(track.uploadedAt)}</span>
                  <span>{formatFileSize(track.fileSize)}</span>
                </div>
              </div>
              
              {/* Play Button */}
              <button
                onClick={() => onPlayTrack(track)}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 p-3 rounded-full transition-all duration-300 transform hover:scale-105"
              >
                {isCurrentTrack(track) && isPlaying ? (
                  <Pause className="w-5 h-5 text-white" />
                ) : (
                  <Play className="w-5 h-5 text-white ml-0.5" />
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};