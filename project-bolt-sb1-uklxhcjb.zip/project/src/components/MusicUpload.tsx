import React, { useState, useCallback } from 'react';
import { Upload, X, Music, Image, AlertCircle } from 'lucide-react';
import { Track } from '../types/music';

interface MusicUploadProps {
  onUpload: (track: Track) => void;
  onCancel: () => void;
}

export const MusicUpload: React.FC<MusicUploadProps> = ({ onUpload, onCancel }) => {
  const [dragActive, setDragActive] = useState(false);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [artworkFile, setArtworkFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileSelect = (file: File) => {
    setError(null);
    
    if (file.type.startsWith('audio/')) {
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        setError('Audio file size must be less than 50MB');
        return;
      }
      setAudioFile(file);
      
      // Auto-fill title from filename
      if (!title) {
        const fileName = file.name.replace(/\.[^/.]+$/, "");
        setTitle(fileName);
      }
    } else if (file.type.startsWith('image/')) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        setError('Image file size must be less than 10MB');
        return;
      }
      setArtworkFile(file);
    } else {
      setError('Please select an audio file (MP3, WAV, etc.) or image file (JPG, PNG, etc.)');
    }
  };

  const getAudioDuration = (file: File): Promise<number> => {
    return new Promise((resolve) => {
      const audio = document.createElement('audio');
      const url = URL.createObjectURL(file);
      audio.src = url;
      
      audio.addEventListener('loadedmetadata', () => {
        URL.revokeObjectURL(url);
        resolve(audio.duration);
      });
      
      audio.addEventListener('error', () => {
        URL.revokeObjectURL(url);
        resolve(0); // Return 0 if duration can't be determined
      });
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!audioFile || !title.trim() || !artist.trim()) {
      setError('Please fill in all required fields and select an audio file');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const duration = await getAudioDuration(audioFile);
      const audioUrl = URL.createObjectURL(audioFile);
      const artworkUrl = artworkFile ? URL.createObjectURL(artworkFile) : undefined;

      const newTrack: Track = {
        id: `track-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        title: title.trim(),
        artist: artist.trim(),
        duration,
        audioUrl,
        artworkUrl,
        uploadedAt: new Date(),
        fileSize: audioFile.size
      };

      onUpload(newTrack);
    } catch (error) {
      setError('Failed to process the audio file. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-2 rounded-xl">
            <Upload className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white">Upload New Track</h2>
        </div>
        <button
          onClick={onCancel}
          className="text-gray-400 hover:text-white transition-colors p-2"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Audio File Upload */}
        <div
          className={`relative border-2 border-dashed rounded-xl p-8 transition-all duration-300 ${
            dragActive
              ? 'border-purple-500 bg-purple-500/10'
              : 'border-gray-600 hover:border-gray-500'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            type="file"
            accept="audio/*"
            onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          
          <div className="text-center">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-3 rounded-xl inline-block mb-4">
              <Music className="w-8 h-8 text-white" />
            </div>
            
            {audioFile ? (
              <div>
                <p className="text-white font-semibold mb-2">{audioFile.name}</p>
                <p className="text-gray-400 text-sm">
                  {(audioFile.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
            ) : (
              <div>
                <p className="text-white font-semibold mb-2">Drop your audio file here</p>
                <p className="text-gray-400 text-sm">
                  or click to browse • Supports MP3, WAV, FLAC, and more
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Artwork Upload */}
        <div className="border border-gray-600 rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Image className="w-5 h-5 text-purple-400" />
            <h3 className="text-white font-semibold">Artwork (Optional)</h3>
          </div>
          
          <input
            type="file"
            accept="image/*"
            onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
            className="w-full text-gray-300 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 transition-colors"
          />
          
          {artworkFile && (
            <div className="mt-3 flex items-center space-x-3">
              <div className="w-16 h-16 bg-gray-700 rounded-lg flex items-center justify-center overflow-hidden">
                <img
                  src={URL.createObjectURL(artworkFile)}
                  alt="Artwork preview"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="text-white text-sm font-medium">{artworkFile.name}</p>
                <p className="text-gray-400 text-xs">
                  {(artworkFile.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Track Info */}
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-white font-medium mb-2">
              Track Title <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter track title"
              className="w-full bg-white/10 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              required
            />
          </div>
          
          <div>
            <label className="block text-white font-medium mb-2">
              Artist <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
              placeholder="Enter artist name"
              className="w-full bg-white/10 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              required
            />
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-500/10 border border-red-500 rounded-lg p-4 flex items-center space-x-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <p className="text-red-400">{error}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex space-x-4 pt-4">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-xl font-semibold transition-colors"
          >
            Cancel
          </button>
          
          <button
            type="submit"
            disabled={!audioFile || !title.trim() || !artist.trim() || isProcessing}
            className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-600 disabled:to-gray-600 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 disabled:hover:scale-100"
          >
            {isProcessing ? 'Processing...' : 'Upload Track'}
          </button>
        </div>
      </form>
    </div>
  );
};