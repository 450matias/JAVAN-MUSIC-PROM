import React, { useState, useEffect } from 'react';
import { Music, Upload, Search, Play, Pause, SkipBack, SkipForward, Volume2, Heart, Shuffle, Repeat } from 'lucide-react';
import { MusicUpload } from './components/MusicUpload';
import { MusicPlayer } from './components/MusicPlayer';
import { MusicGrid } from './components/MusicGrid';
import { Header } from './components/Header';
import { Track } from './types/music';

function App() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showUpload, setShowUpload] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Load tracks from localStorage on mount
  useEffect(() => {
    const storedTracks = localStorage.getItem('javanMusicTracks');
    if (storedTracks) {
      setTracks(JSON.parse(storedTracks));
    }
  }, []);

  // Save tracks to localStorage whenever tracks change
  useEffect(() => {
    localStorage.setItem('javanMusicTracks', JSON.stringify(tracks));
  }, [tracks]);

  const handleTrackUpload = (newTrack: Track) => {
    setTracks(prev => [...prev, newTrack]);
    setShowUpload(false);
  };

  const handlePlayTrack = (track: Track) => {
    setCurrentTrack(track);
    setIsPlaying(true);
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const filteredTracks = tracks.filter(track =>
    track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    track.artist.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Header 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onUploadClick={() => setShowUpload(true)}
      />

      <main className="container mx-auto px-4 py-8">
        {showUpload ? (
          <MusicUpload
            onUpload={handleTrackUpload}
            onCancel={() => setShowUpload(false)}
          />
        ) : (
          <>
            {tracks.length === 0 ? (
              <div className="text-center py-20">
                <Music className="w-20 h-20 text-purple-400 mx-auto mb-6" />
                <h2 className="text-3xl font-bold text-white mb-4">Welcome to Javan Music</h2>
                <p className="text-gray-400 mb-8 max-w-md mx-auto">
                  Start building your music library by uploading your favorite tracks and artwork.
                </p>
                <button
                  onClick={() => setShowUpload(true)}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105"
                >
                  Upload Your First Track
                </button>
              </div>
            ) : (
              <>
                <div className="mb-8">
                  <h2 className="text-3xl font-bold text-white mb-2">
                    {searchQuery ? 'Search Results' : 'Your Music Library'}
                  </h2>
                  <p className="text-gray-400">
                    {filteredTracks.length} {filteredTracks.length === 1 ? 'track' : 'tracks'} available
                  </p>
                </div>

                <MusicGrid
                  tracks={filteredTracks}
                  currentTrack={currentTrack}
                  isPlaying={isPlaying}
                  onPlayTrack={handlePlayTrack}
                />
              </>
            )}
          </>
        )}
      </main>

      {currentTrack && (
        <MusicPlayer
          track={currentTrack}
          isPlaying={isPlaying}
          onPlayPause={handlePlayPause}
          tracks={tracks}
          onTrackChange={setCurrentTrack}
        />
      )}
    </div>
  );
}

export default App;