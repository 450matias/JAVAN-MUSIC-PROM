export interface Track {
  id: string;
  title: string;
  artist: string;
  duration: number;
  audioUrl: string;
  artworkUrl?: string;
  uploadedAt: Date;
  fileSize: number;
}

export interface PlaylistState {
  currentIndex: number;
  isShuffled: boolean;
  repeatMode: 'none' | 'one' | 'all';
}